/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdint.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct
{
    uint16_t samples[20]; /* ADC_HALF_LEN = N_CH * FRAMES_PER_BLOCK = 1 * 20 */
    uint32_t seq_start;
    uint8_t frame_offset;
} TxBlock;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define N_CH 1                              /* 只保留 CH4 (ADC_CHANNEL_8) */
#define FRAMES_PER_BLOCK 20

#define ADC_HALF_LEN (N_CH * FRAMES_PER_BLOCK)
#define ADC_DMA_LEN  (2U * ADC_HALF_LEN)

#define TX_BLOCK_QUEUE_SIZE 16U

#define BIN_SYNC1 0xAAU
#define BIN_SYNC2 0x55U
#define BIN_STATUS_VALID 0U
#define BIN_STATUS_LOST  1U
#define BIN_PKT_SIZE     17U

/* 17 bytes per packet, use a multiple of 17 */
#define TX_BUF_SIZE      2040U

#define LOST_SENTINEL 65535U
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_tx;

/* USER CODE BEGIN PV */
/* ADC DMA layout (single channel):
   ch4 | ch4 | ch4 | ...
*/
uint16_t adc_dma_buf[ADC_DMA_LEN];

/* Flags set by DMA callbacks */
volatile uint8_t adc_half_ready;
volatile uint8_t adc_full_ready;
volatile uint32_t adc_half_seq_start;
volatile uint32_t adc_full_seq_start;
volatile uint32_t adc_seq_counter;

/* One processed half block buffer */
uint16_t filt_block[ADC_HALF_LEN];

/* UART TX queue */
TxBlock tx_queue[TX_BLOCK_QUEUE_SIZE];
volatile uint8_t tx_q_head;
volatile uint8_t tx_q_tail;
volatile uint8_t tx_q_count;

/* UART DMA double buffer */
volatile uint8_t uart_tx_busy;
uint8_t tx_buf[2][TX_BUF_SIZE];
volatile uint8_t tx_sel;

/* Diagnostics counters */
volatile uint32_t adc_half_overrun;
volatile uint32_t adc_full_overrun;
volatile uint32_t tx_queue_overrun;

/* Next sequence number that should be sent to frontend */
uint32_t next_tx_seq;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);

/* USER CODE BEGIN PFP */
static void ProcessBlock(const uint16_t *in, uint16_t *out, int frames);
static uint8_t FetchNextAdcBlock(const uint16_t **in, uint32_t *seq_start);
static void EnqueueProcessedBlock(const uint16_t *out, uint32_t seq_start);
static void TryStartUartTx(void);
static uint16_t crc16_ccitt_false(const uint8_t *data, uint16_t len);
static inline void wr_u16_le(uint8_t *dst, uint16_t v);
static inline void wr_u32_le(uint8_t *dst, uint32_t v);
static inline int append_frame_bin_packet(uint8_t *dst, int remaining,
                                          uint32_t seq, uint8_t status,
                                          uint16_t a, uint16_t b,
                                          uint16_t c, uint16_t d);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static uint16_t crc16_ccitt_false(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFFU;

    for (uint16_t i = 0; i < len; i++)
    {
        crc ^= ((uint16_t)data[i] << 8);

        for (uint8_t b = 0; b < 8; b++)
        {
            if (crc & 0x8000U)
            {
                crc = (uint16_t)((crc << 1) ^ 0x1021U);
            }
            else
            {
                crc <<= 1;
            }
        }
    }

    return crc;
}

static inline void wr_u16_le(uint8_t *dst, uint16_t v)
{
    dst[0] = (uint8_t)(v & 0xFFU);
    dst[1] = (uint8_t)((v >> 8) & 0xFFU);
}

static inline void wr_u32_le(uint8_t *dst, uint32_t v)
{
    dst[0] = (uint8_t)(v & 0xFFU);
    dst[1] = (uint8_t)((v >> 8) & 0xFFU);
    dst[2] = (uint8_t)((v >> 16) & 0xFFU);
    dst[3] = (uint8_t)((v >> 24) & 0xFFU);
}

static inline int append_frame_bin_packet(uint8_t *dst, int remaining,
                                          uint32_t seq, uint8_t status,
                                          uint16_t a, uint16_t b,
                                          uint16_t c, uint16_t d)
{
    if (remaining < (int)BIN_PKT_SIZE)
    {
        return -1;
    }

    dst[0] = BIN_SYNC1;
    dst[1] = BIN_SYNC2;
    wr_u32_le(&dst[2], seq);
    dst[6] = status;
    wr_u16_le(&dst[7], a);
    wr_u16_le(&dst[9], b);
    wr_u16_le(&dst[11], c);
    wr_u16_le(&dst[13], d);

    uint16_t crc = crc16_ccitt_false(dst, 15);
    wr_u16_le(&dst[15], crc);

    return (int)BIN_PKT_SIZE;
}

static inline int u16_to_ascii(uint16_t v, char *dst)
{
    char tmp[5];
    int n = 0;
    int k = 0;

    if (v == 0U)
    {
        dst[0] = '0';
        return 1;
    }

    while (v > 0U)
    {
        tmp[n++] = (char)('0' + (v % 10U));
        v /= 10U;
    }

    while (n > 0)
    {
        dst[k++] = tmp[--n];
    }

    return k;
}

static inline int u32_to_ascii(uint32_t v, char *dst)
{
    char tmp[10];
    int n = 0;
    int k = 0;

    if (v == 0U)
    {
        dst[0] = '0';
        return 1;
    }

    while (v > 0U)
    {
        tmp[n++] = (char)('0' + (v % 10U));
        v /= 10U;
    }

    while (n > 0)
    {
        dst[k++] = tmp[--n];
    }

    return k;
}

static inline int append_frame_csv_line(char *dst, int remaining,
                                        uint32_t seq, uint8_t status,
                                        uint16_t a, uint16_t b, uint16_t c, uint16_t d)
{
    int pos = 0;
    int n;

    if (remaining <= 0)
    {
        return -1;
    }

    n = u32_to_ascii(seq, &dst[pos]);
    pos += n;
    if (pos >= remaining) return -1;
    dst[pos++] = ',';

    n = u16_to_ascii((uint16_t)status, &dst[pos]);
    pos += n;
    if (pos >= remaining) return -1;
    dst[pos++] = ',';

    n = u16_to_ascii(a, &dst[pos]);
    pos += n;
    if (pos >= remaining) return -1;
    dst[pos++] = ',';

    n = u16_to_ascii(b, &dst[pos]);
    pos += n;
    if (pos >= remaining) return -1;
    dst[pos++] = ',';

    n = u16_to_ascii(c, &dst[pos]);
    pos += n;
    if (pos >= remaining) return -1;
    dst[pos++] = ',';

    n = u16_to_ascii(d, &dst[pos]);
    pos += n;
    if (pos >= remaining) return -1;
    dst[pos++] = '\n';

    if (pos > remaining) return -1;
    return pos;
}


static void ProcessBlock(const uint16_t *in, uint16_t *out, int frames)
{
    memcpy(out, in, (size_t)(frames * N_CH) * sizeof(uint16_t));
}

static uint8_t FetchNextAdcBlock(const uint16_t **in, uint32_t *seq_start)
{
    uint8_t have_half;
    uint8_t have_full;
    uint32_t half_seq;
    uint32_t full_seq;

    __disable_irq();
    have_half = adc_half_ready;
    have_full = adc_full_ready;
    half_seq = adc_half_seq_start;
    full_seq = adc_full_seq_start;

    if ((have_half == 0U) && (have_full == 0U))
    {
        __enable_irq();
        return 0U;
    }

    if ((have_half != 0U) && ((have_full == 0U) || ((int32_t)(half_seq - full_seq) <= 0)))
    {
        adc_half_ready = 0U;
        *in = &adc_dma_buf[0];
        *seq_start = half_seq;
    }
    else
    {
        adc_full_ready = 0U;
        *in = &adc_dma_buf[ADC_HALF_LEN];
        *seq_start = full_seq;
    }

    __enable_irq();
    return 1U;
}

static void EnqueueProcessedBlock(const uint16_t *out, uint32_t seq_start)
{
    if (tx_q_count >= TX_BLOCK_QUEUE_SIZE)
    {
        tx_queue_overrun++;
        return;
    }

    TxBlock *slot = &tx_queue[tx_q_tail];
    memcpy(slot->samples, out, sizeof(slot->samples));
    slot->seq_start = seq_start;
    slot->frame_offset = 0U;

    tx_q_tail = (uint8_t)((tx_q_tail + 1U) % TX_BLOCK_QUEUE_SIZE);
    tx_q_count++;
}

static void TryStartUartTx(void)
{
    if (uart_tx_busy) return;
    if (tx_q_count == 0U) return;

    uint8_t sel = (uint8_t)(tx_sel ^ 1U);
    tx_sel = sel;

    int pos = 0;
    uint8_t *dst = &tx_buf[sel][0];

    while (pos <= ((int)TX_BUF_SIZE - (int)BIN_PKT_SIZE))
    {
        if (tx_q_count == 0U)
        {
            break;
        }

        TxBlock *head = &tx_queue[tx_q_head];
        uint32_t head_seq = head->seq_start + (uint32_t)head->frame_offset;

        if (next_tx_seq > head_seq)
        {
            uint32_t skip = next_tx_seq - head_seq;

            if (skip >= (uint32_t)(FRAMES_PER_BLOCK - head->frame_offset))
            {
                tx_q_head = (uint8_t)((tx_q_head + 1U) % TX_BLOCK_QUEUE_SIZE);
                tx_q_count--;
                continue;
            }

            head->frame_offset = (uint8_t)(head->frame_offset + skip);
            head_seq = head->seq_start + (uint32_t)head->frame_offset;
        }

        /* Fill explicit lost packets if seq has a gap */
        if (next_tx_seq < head_seq)
        {
            int n = append_frame_bin_packet(&dst[pos],
                                            (int)TX_BUF_SIZE - pos,
                                            next_tx_seq,
                                            BIN_STATUS_LOST,
                                            LOST_SENTINEL,
                                            LOST_SENTINEL,
                                            LOST_SENTINEL,
                                            LOST_SENTINEL);
            if (n < 0) break;

            pos += n;
            next_tx_seq++;
            continue;
        }

        while ((head->frame_offset < FRAMES_PER_BLOCK) &&
               (pos <= ((int)TX_BUF_SIZE - (int)BIN_PKT_SIZE)))
        {
            uint16_t *s = &head->samples[head->frame_offset * N_CH];

            /* Only CH4 data in s[0]; b/c/d slots filled with 0 */
            int n = append_frame_bin_packet(&dst[pos],
                                            (int)TX_BUF_SIZE - pos,
                                            next_tx_seq,
                                            BIN_STATUS_VALID,
                                            s[0], 0U, 0U, 0U);
            if (n < 0) break;

            pos += n;
            head->frame_offset++;
            next_tx_seq++;
        }

        if (head->frame_offset >= FRAMES_PER_BLOCK)
        {
            tx_q_head = (uint8_t)((tx_q_head + 1U) % TX_BLOCK_QUEUE_SIZE);
            tx_q_count--;
        }
        else
        {
            break;
        }
    }

    if (pos <= 0) return;

    uart_tx_busy = 1U;

    if (HAL_UART_Transmit_DMA(&huart2, &tx_buf[sel][0], (uint16_t)pos) != HAL_OK)
    {
        uart_tx_busy = 0U;
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  HAL_Init();

  /* USER CODE BEGIN Init */
  DBGMCU->CR |= DBGMCU_CR_DBG_SLEEP;
  /* USER CODE END Init */

  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();

  /* USER CODE BEGIN 2 */

  adc_half_ready = 0U;
  adc_full_ready = 0U;
  adc_half_seq_start = 0U;
  adc_full_seq_start = 0U;
  adc_seq_counter = 0U;

  tx_q_head = 0U;
  tx_q_tail = 0U;
  tx_q_count = 0U;

  next_tx_seq = 0U;

  uart_tx_busy = 0U;
  tx_sel = 0U;

  adc_half_overrun = 0U;
  adc_full_overrun = 0U;
  tx_queue_overrun = 0U;

  if (HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adc_dma_buf, ADC_DMA_LEN) != HAL_OK)
  {
      Error_Handler();
  }

  if (HAL_TIM_Base_Start(&htim2) != HAL_OK)
  {
      Error_Handler();
  }

#ifndef NDEBUG
  /* keep SysTick running in debug */
#else
  HAL_SuspendTick();
#endif
  /* USER CODE END 2 */

  while (1)
  {
    /* USER CODE BEGIN 3 */
    const uint16_t *adc_block_ptr;
    uint32_t seq_start;

    while (FetchNextAdcBlock(&adc_block_ptr, &seq_start) != 0U)
    {
        ProcessBlock(adc_block_ptr, filt_block, FRAMES_PER_BLOCK);
        EnqueueProcessedBlock(filt_block, seq_start);
    }

    TryStartUartTx();

#ifndef NDEBUG
    /* do not sleep in debug */
#else
    if ((adc_half_ready == 0U) &&
        (adc_full_ready == 0U) &&
        ((uart_tx_busy != 0U) || (tx_q_count == 0U)))
    {
        __WFI();
    }
#endif
    /* USER CODE END 3 */
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK |
                                RCC_CLOCKTYPE_SYSCLK |
                                RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T2_TRGO;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;          /* 只保留 CH4 */
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /* CH4 = ADC_CHANNEL_8, Rank 1 */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 83;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 499;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 921600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{
  __HAL_RCC_DMA2_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  HAL_NVIC_SetPriority(DMA1_Stream6_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream6_IRQn);

  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1)
    {
        uint32_t seq = adc_seq_counter;
        adc_seq_counter += FRAMES_PER_BLOCK;

        if (adc_half_ready != 0U)
        {
            adc_half_overrun++;
        }

        adc_half_seq_start = seq;
        adc_half_ready = 1U;
    }
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1)
    {
        uint32_t seq = adc_seq_counter;
        adc_seq_counter += FRAMES_PER_BLOCK;

        if (adc_full_ready != 0U)
        {
            adc_full_overrun++;
        }

        adc_full_seq_start = seq;
        adc_full_ready = 1U;
    }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        uart_tx_busy = 0U;
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        uart_tx_busy = 0U;
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* Add your own reporting here if needed */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
